// routes/provider/post.js
const express = require("express");
const router  = express.Router();
const multer  = require("multer"); // Garder multer pour les cas où vous en auriez besoin, même si .none() est utilisé
const createProvider = require("../../controllers/provider/createProvider");
const { isPostMethod } = require("../../librairies/method");
const { jsonResponse } = require("../../librairies/response");

const upload = multer().none(); // Pour s'assurer que req.body est bien parsé pour les champs non-fichier

router.post("/", upload, async (req, res) => {
    if (!isPostMethod(req)) {
        return jsonResponse(res, 405, {}, { message: "Method Not Allowed" });
    }

    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
        return jsonResponse(res, 401, {}, { message: "Token missing or invalid" });
    }

    const token = authHeader.split(" ")[1];

    try {
        const result = await createProvider(token, req.body);
        return jsonResponse(res, 201, {}, result);
    } catch (err) {
        // AJOUTEZ CETTE LIGNE : Cela va loguer l'erreur sur la console de votre serveur
        console.error("Erreur serveur lors de la création du prestataire:", err);
        return jsonResponse(res, 500, {}, { message: err.message || "Erreur interne du serveur" });
    }
});

module.exports = router;