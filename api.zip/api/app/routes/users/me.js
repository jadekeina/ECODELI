const express = require("express");
const router = express.Router();
const authMiddleware = require("../../librairies/authMiddleware");


router.get("/me", authMiddleware, async (req, res) => {
  try {
    if (req.user && req.user.password) {
      delete req.user.password;
    }
    res.status(200).json({ message: "Utilisateur connecté ✅", user: req.user });
  } catch (error) {
    console.error("Erreur inattendue dans la route /me après authentification:", error);
    res.status(500).json({ message: "Erreur serveur inattendue" });
  }
});

module.exports = router;