// controllers/deliveryDriver/createDeliveryDriver.js
const jwt = require("jsonwebtoken");
const db = require("../../models/provider");
const AddressModel = require("../../models/address");

async function createDeliveryDriver(token, data) {
    try {
        const decoded = jwt.verify(token, process.env.SECRET_KEY);
        const userId = decoded.userId;

        return new Promise((resolve, reject) => {
            if (!data.zone_deplacement) {
                return reject(new Error("Champ 'zone_deplacement' manquant"));
            }

            AddressModel.insertAddress(data.zone_deplacement, (err, zoneAddressResult) => {
                if (err) return reject(err);

                const zoneAddressId = zoneAddressResult.insertId;

                // Adresse personnelle facultative
                if (data.adresse_personnelle) {
                    AddressModel.insertAddress(data.adresse_personnelle, (err2, homeAddressResult) => {
                        if (err2) return reject(err2);

                        const homeAddressId = homeAddressResult.insertId;

                        db.query(
                            `INSERT INTO delivery_driver (user_id, zone_address_id, home_address_id) VALUES (?, ?, ?)`,
                            [userId, zoneAddressId, homeAddressId],
                            (err3) => {
                                if (err3) return reject(err3);
                                resolve({ message: "Profil chauffeur créé avec succès" });
                            }
                        );
                    });
                } else {
                    db.query(
                        `INSERT INTO delivery_driver (user_id, zone_address_id) VALUES (?, ?)`,
                        [userId, zoneAddressId],
                        (err4) => {
                            if (err4) return reject(err4);
                            resolve({ message: "Profil chauffeur créé avec succès" });
                        }
                    );
                }
            });
        });
    } catch (err) {
        throw new Error("Token invalide ou expiré");
    }
}

module.exports = createDeliveryDriver;
