// controllers/provider/createProvider.js
const jwt = require("jsonwebtoken");
const ProviderModel = require("../../models/provider");
const AddressModel  = require("../../models/address");

async function createProvider(token, data) {
    try {
        const decoded = jwt.verify(token, process.env.SECRET_KEY);
        const userId  = decoded.userId;

        // CHANGEMENT ICI : Utilisez les noms de champs du frontend
        const { type_prestation, zone_deplacement } = data;
        if (!type_prestation || !zone_deplacement) {
            throw new Error("Champs 'type_prestation' ou 'zone_deplacement' manquants");
        }

        // 1) Insérer l'adresse et récupérer son id
        const addressId = await new Promise((resolve, reject) => {
            AddressModel.insertAddress(zone_deplacement, (err, result) => { // Utilisez zone_deplacement
                if (err) return reject(err);
                resolve(result.insertId);
            });
        });

        // 2) Insérer le prestataire avec l'adresse
        await new Promise((resolve, reject) => {
            ProviderModel.createProvider(
                userId,
                type_prestation, // Utilisez type_prestation
                '',
                addressId,
                (err) => (err ? reject(err) : resolve())
            );
        });

        return { message: "Compte prestataire créé avec succès" };
    } catch (err) {
        throw err;
    }
}

module.exports = createProvider;