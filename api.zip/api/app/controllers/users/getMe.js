const db = require("../../models/users");
const isUserLoggedIn = require("../../librairies/user-is-logged-in");

async function getMe(token) {
  try {
    const decoded = isUserLoggedIn(token); // récupère userId depuis le token

    // 🔍 Ajoute ici tes logs de debug :
    console.log("🔑 Contenu du token :", decoded);
    console.log("🧠 ID utilisé pour la requête :", decoded.userId);

    const userId = decoded.userId;

    return new Promise((resolve, reject) => {
      db.getUserById(userId, (err, result) => {
        if (err) return reject(new Error("Erreur lors de la récupération"));
        if (!result || !result.length) return reject(new Error("User not found"));

        const user = result[0];
        delete user.password;
        resolve(user);
      });
    });
  } catch (err) {
    console.error("⛔ Erreur dans getMe :", err.message);
    throw new Error("Token invalide");
  }
}

module.exports = getMe;
